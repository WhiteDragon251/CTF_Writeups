// export const Values = [1, 2, 3] as const;

export interface AccessTokenResponse {
  accessToken: string;
}

